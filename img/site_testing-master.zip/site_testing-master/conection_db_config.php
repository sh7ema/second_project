<?php
$host = 'localhost'; // адрес сервера 
$database = 'testrow'; // имя базы данных
$user = 'root'; // имя пользователя
$password = ''; // пароль
?>